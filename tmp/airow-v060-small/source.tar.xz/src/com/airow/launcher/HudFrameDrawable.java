package com.airow.launcher;

import android.graphics.*;
import android.graphics.drawable.Drawable;

/** Low-chrome HUD surface: tint, one accent rail, and technical corner marks. */
public final class HudFrameDrawable extends Drawable {
  private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
  private final int fill, accent;
  private final float density;

  public HudFrameDrawable(int fill, int accent, float density) {
    this.fill=fill; this.accent=accent; this.density=density;
  }

  @Override public void draw(Canvas c) {
    Rect b=getBounds(); float d=density, cut=14*d, corner=18*d;
    Path shape=new Path();
    shape.moveTo(b.left+cut,b.top); shape.lineTo(b.right-corner,b.top);
    shape.lineTo(b.right,b.top+corner); shape.lineTo(b.right,b.bottom-cut);
    shape.lineTo(b.right-cut,b.bottom); shape.lineTo(b.left+corner,b.bottom);
    shape.lineTo(b.left,b.bottom-corner); shape.lineTo(b.left,b.top+cut); shape.close();
    p.setStyle(Paint.Style.FILL); p.setColor(fill); c.drawPath(shape,p);
    p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(Math.max(1,d)); p.setColor(0x343a4d5b); c.drawPath(shape,p);

    p.setStrokeWidth(2*d); p.setColor(accent); p.setStrokeCap(Paint.Cap.SQUARE);
    c.drawLine(b.left+cut,b.top,b.left+cut+34*d,b.top,p);
    c.drawLine(b.right,b.bottom-25*d,b.right,b.bottom-10*d,p);

    p.setStrokeWidth(d); p.setColor(0x5570808e);
    c.drawLine(b.left+8*d,b.bottom,b.left+42*d,b.bottom,p);
  }
  @Override public void setAlpha(int alpha) {}
  @Override public void setColorFilter(android.graphics.ColorFilter colorFilter) {}
  @Override public int getOpacity(){return PixelFormat.TRANSLUCENT;}
}
