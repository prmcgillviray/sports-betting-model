package com.airow.launcher;

import android.content.Context;
import android.graphics.*;
import android.view.*;

/** Animated assistant core: lightweight Canvas HUD with no image assets. */
public final class AiCoreView extends View {
  private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
  private int accent = 0xffd3ff57;
  private boolean active = true;

  public AiCoreView(Context context) {
    super(context);
    setClickable(true);
    setFocusable(true);
    setContentDescription("Open AI assistant");
  }

  public void accent(int color) { accent = color; invalidate(); }
  public void active(boolean value) { active = value; invalidate(); }

  @Override protected void onDraw(Canvas c) {
    super.onDraw(c);
    float w = getWidth(), h = getHeight(), cx = w / 2f, cy = h / 2f;
    float r = Math.min(w, h) * .34f;
    float t = (System.currentTimeMillis() % 5000L) / 5000f;
    float pulse = .92f + .08f * (float)Math.sin(t * Math.PI * 2);

    p.setStyle(Paint.Style.FILL);
    p.setColor(0x17000000 | (accent & 0x00ffffff));
    p.setShadowLayer(r * .28f, 0, 0, accent);
    c.drawCircle(cx, cy, r * .72f * pulse, p);
    p.clearShadowLayer();

    p.setStyle(Paint.Style.STROKE);
    p.setStrokeCap(Paint.Cap.ROUND);
    p.setStrokeWidth(dp(1));
    p.setColor(withAlpha(accent, 58));
    c.drawCircle(cx, cy, r, p);
    c.drawCircle(cx, cy, r * .78f, p);

    RectF outer = new RectF(cx-r, cy-r, cx+r, cy+r);
    p.setStrokeWidth(dp(2.2f));
    p.setColor(withAlpha(accent, active ? 225 : 95));
    c.drawArc(outer, t * 360f - 70f, 108f, false, p);
    c.drawArc(outer, t * 360f + 125f, 34f, false, p);

    float rr = r * .58f;
    RectF inner = new RectF(cx-rr, cy-rr, cx+rr, cy+rr);
    p.setStrokeWidth(dp(1.3f));
    p.setColor(0x99ffffff);
    c.drawArc(inner, -t * 480f, 62f, false, p);
    c.drawArc(inner, 180f - t * 480f, 32f, false, p);

    p.setStyle(Paint.Style.FILL);
    p.setColor(accent);
    c.drawCircle(cx, cy, dp(4.2f) * pulse, p);
    p.setColor(0xffffffff);
    c.drawCircle(cx, cy, dp(1.6f), p);

    // Four subtle targeting ticks.
    p.setStyle(Paint.Style.STROKE);
    p.setStrokeWidth(dp(1));
    p.setColor(withAlpha(accent, 120));
    for (int i = 0; i < 4; i++) {
      double a = Math.PI * .5 * i;
      float x1 = cx + (float)Math.cos(a) * r * 1.18f;
      float y1 = cy + (float)Math.sin(a) * r * 1.18f;
      float x2 = cx + (float)Math.cos(a) * r * 1.34f;
      float y2 = cy + (float)Math.sin(a) * r * 1.34f;
      c.drawLine(x1, y1, x2, y2, p);
    }

  }

  private int withAlpha(int color, int alpha) { return (alpha << 24) | (color & 0x00ffffff); }
  private float dp(float n) { return n * getResources().getDisplayMetrics().density; }
}
